# Python库提供的一种打包方式
from distutils.core import setup

setup(
    name="message_module",
    version="1.0",
    author="kyaing",
    author_email="kyaing@163.com",
    py_modules=['Message.SendMsg'],
)